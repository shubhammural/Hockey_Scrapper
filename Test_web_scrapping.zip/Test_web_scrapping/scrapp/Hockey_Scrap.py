import aiohttp
import asyncio
from bs4 import BeautifulSoup
from zipfile import ZipFile
from openpyxl import Workbook
import time
from typing import List

class HockeyStatsScraper:
    def __init__(self):
        self.base_url = "https://www.scrapethissite.com/pages/forms/?page_num="

    # Fetching  HTML content from a  URL
    async def fetch_html(self, session: aiohttp.ClientSession, url: str) -> str:
        async with session.get(url) as response:
            return await response.text()


   # this function Scrape multiple pages and return their HTML content
    async def scrape_pages(self) -> List[str]:
        async with aiohttp.ClientSession() as session:
            tasks = [self.fetch_html(session, f"{self.base_url}{i}") for i in range(1, 25)]
            html_pages = await asyncio.gather(*tasks)
        return html_pages

# this function save HTML pages to a ZIP file, with each page stored as a separate file
    def save_html_to_zip(self, html_pages: List[str]) -> None:
        with ZipFile("hockey_stats.zip", "w") as zipf:
            for i, html in enumerate(html_pages, 1):
                zipf.writestr(f"{i}.html", html)

# extracting team data
    def parse_team_data(self, html: str) -> List[List[str]]:
        soup = BeautifulSoup(html, 'html.parser')
        rows = soup.select('tr.team')
        return [[td.text.strip() for td in row.find_all('td')] for row in rows]

    def create_excel_file(self, all_team_stats: List[List[str]]) -> None:
        wb = Workbook()

        sheet1 = wb.active
        sheet1.title = "NHL Stats 1990-2011"
        sheet1.append(
            ["Team Name", "Year", "Wins", "Losses", "OT Losses", "Win %", "Goals For (GF)", "Goals Against (GA)", "+ / -"])

        for team in all_team_stats:
            sheet1.append(team)

        sheet2 = wb.create_sheet("Winner and Loser per Year")

        year_stats = {}
        for team in all_team_stats:
            year, wins = team[1], int(team[2])
            if year not in year_stats:
                year_stats[year] = []
            year_stats[year].append(team)

        sheet2.append(['Year', 'Winner', 'Winner Num. of Wins', 'Loser', 'Loser Num. of Wins'])
        for year, teams in year_stats.items():
            winner = max(teams, key=lambda x: int(x[2]))
            loser = min(teams, key=lambda x: int(x[2]))
            winner_wins = winner[2]
            loser_wins = loser[2]
            sheet2.append([year, winner[0], winner_wins, loser[0], loser_wins])

        wb.save("hockey_stats.xlsx")

    async def run(self) -> None:
        start_time = time.time()

        html_pages = await self.scrape_pages()
        self.save_html_to_zip(html_pages)
        all_team_stats = [team for html in html_pages for team in self.parse_team_data(html)]
        self.create_excel_file(all_team_stats)

        end_time = time.time()
        print(f"Execution Time: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    scraper = HockeyStatsScraper()
    asyncio.run(scraper.run())
