import pytest
from unittest.mock import patch, MagicMock,mock_open
from scrapp.Hockey_Scrap import HockeyStatsScraper


# Test case for parse_team_data
def test_parse_team_data():
    scraper = HockeyStatsScraper()

    # Sample HTML content
    html = '''
    <html>
        <body>
            <table>
                <tr class="team">
                    <td>Team A</td>
                    <td>2023</td>
                    <td>30</td>
                    <td>20</td>
                    <td>5</td>
                    <td>0.600</td>
                    <td>150</td>
                    <td>100</td>
                    <td>+50</td>
                </tr>
                <tr class="team">
                    <td>Team B</td>
                    <td>2023</td>
                    <td>25</td>
                    <td>25</td>
                    <td>5</td>
                    <td>0.500</td>
                    <td>120</td>
                    <td>120</td>
                    <td>0</td>
                </tr>
            </table>
        </body>
    </html>
    '''

    expected_result = [
        ["Team A", "2023", "30", "20", "5", "0.600", "150", "100", "+50"],
        ["Team B", "2023", "25", "25", "5", "0.500", "120", "120", "0"]
    ]

    result = scraper.parse_team_data(html)
    assert result == expected_result


# Test case for create_excel_file
@patch('scrapp.Hockey_Scrap.Workbook')
def test_create_excel_file(MockWorkbook):
    scraper = HockeyStatsScraper()

    # Sample team data
    all_team_stats = [
        ["Team A", "2023", "30", "20", "5", "0.600", "150", "100", "+50"],
        ["Team B", "2023", "25", "25", "5", "0.500", "120", "120", "0"]
    ]

    # Mock Workbook and its methods
    mock_wb = MockWorkbook.return_value
    mock_sheet1 = mock_wb.active
    mock_sheet2 = mock_wb.create_sheet.return_value

    # Call the method under test
    scraper.create_excel_file(all_team_stats)

    # Verify Workbook and Sheet interactions
    MockWorkbook.assert_called_once()
    mock_sheet1.append.assert_any_call(
        ["Team Name", "Year", "Wins", "Losses", "OT Losses", "Win %", "Goals For (GF)", "Goals Against (GA)", "+ / -"]
    )
    mock_sheet1.append.assert_any_call(["Team A", "2023", "30", "20", "5", "0.600", "150", "100", "+50"])
    mock_sheet1.append.assert_any_call(["Team B", "2023", "25", "25", "5", "0.500", "120", "120", "0"])
    mock_sheet2.append.assert_any_call(['Year', 'Winner', 'Winner Num. of Wins', 'Loser', 'Loser Num. of Wins'])
    mock_sheet2.append.assert_any_call(['2023', 'Team A', '30', 'Team B', '25'])
